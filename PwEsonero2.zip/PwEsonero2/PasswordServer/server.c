#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <arpa/inet.h>
#include <unistd.h> // For close()
#include <time.h>   // For srand() and rand()
#include "protocol.h"

// Generates numeric passwords (digits only)
char *generate_numeric(int length) {
    char *password = malloc(length + 1);
    for (int i = 0; i < length; i++) {
        password[i] = '0' + rand() % 10; // Generate a random digit
    }
    password[length] = '\0'; // Null-terminate the string
    return password;
}

// Generates alphabetic passwords (lowercase letters only)
char *generate_alpha(int length) {
    char *password = malloc(length + 1);
    for (int i = 0; i < length; i++) {
        password[i] = 'a' + rand() % 26; // Generate a random lowercase letter
    }
    password[length] = '\0'; // Null-terminate the string
    return password;
}

// Generates mixed passwords (lowercase letters and digits)
char *generate_mixed(int length) {
    char *password = malloc(length + 1);
    for (int i = 0; i < length; i++) {
        password[i] = (rand() % 2) ? 'a' + rand() % 26 : '0' + rand() % 10; // Randomly choose between letter or digit
    }
    password[length] = '\0'; // Null-terminate the string
    return password;
}

// Generates secure passwords (letters, digits, symbols)
char *generate_secure(int length) {
    const char charset[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";
    char *password = malloc(length + 1);
    for (int i = 0; i < length; i++) {
        password[i] = charset[rand() % (sizeof(charset) - 1)]; // Choose a random character from the charset
    }
    password[length] = '\0'; // Null-terminate the string
    return password;
}

// Generates unambiguous passwords (no similar-looking characters)
char *generate_unambiguous(int length) {
    const char charset[] = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz234679"; // Exclude ambiguous characters like I, O, 0, 1, l
    char *password = malloc(length + 1);
    for (int i = 0; i < length; i++) {
        password[i] = charset[rand() % (sizeof(charset) - 1)]; // Choose a random character from the charset
    }
    password[length] = '\0'; // Null-terminate the string
    return password;
}

int main() {
    srand(time(NULL)); // Seed the random number generator

    // Create a UDP socket
    int server_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (server_socket < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in server_addr = {0}, client_addr = {0};
    socklen_t client_addr_len = sizeof(client_addr);

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind the socket to the server address
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    printf("Server running...\n");

    char buffer[BUFFER_SIZE];
    while (1) {
        // Receive a request from a client
        int bytes_received = recvfrom(server_socket, buffer, BUFFER_SIZE, 0,
                                      (struct sockaddr *)&client_addr, &client_addr_len);
        if (bytes_received < 0) {
            perror("Receive failed");
            continue;
        }

        buffer[bytes_received] = '\0'; // Null-terminate the received string
        printf("New request from %s:%d\n",
               inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

        char command;
        int length;
        // Parse the command and length from the received message
        if (sscanf(buffer, "%c %d", &command, &length) == 2) {
            // Validate the length
            if (length < MIN_PASSWORD_LENGTH || length > MAX_PASSWORD_LENGTH) {
                const char *error_msg = "Invalid length. Must be between 6 and 32.";
                sendto(server_socket, error_msg, strlen(error_msg), 0,
                       (struct sockaddr *)&client_addr, client_addr_len);
                continue;
            }

            char *password = NULL;
            // Generate the password based on the command received
            switch (command) {
                case CMD_NUMERIC:
                    password = generate_numeric(length);
                    break;
                case CMD_ALPHA:
                    password = generate_alpha(length);
                    break;
                case CMD_MIXED:
                    password = generate_mixed(length);
                    break;
                case CMD_SECURE:
                    password = generate_secure(length);
                    break;
                case CMD_UNAMBIGUOUS:
                    password = generate_unambiguous(length);
                    break;
                default:
                    password = strdup("Invalid command");
            }

            // Send the generated password back to the client
            sendto(server_socket, password, strlen(password), 0,
                   (struct sockaddr *)&client_addr, client_addr_len);
            free(password); // Free the dynamically allocated password
        }
    }

    // Close the server socket
    close(server_socket);
    return 0;
}

