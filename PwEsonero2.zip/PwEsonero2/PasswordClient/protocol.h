#ifndef PROTOCOL_H
#define PROTOCOL_H

// Server configuration
#define SERVER_PORT 12345
#define SERVER_ADDRESS "127.0.0.1" // Replace with "passwdgen.uniba.it" for real deployment

// Password length constraints
#define MAX_PASSWORD_LENGTH 32
#define MIN_PASSWORD_LENGTH 6

// Buffer size for communication
#define BUFFER_SIZE 1024

// Command definitions
#define CMD_HELP 'h'
#define CMD_QUIT 'q'
#define CMD_NUMERIC 'n'
#define CMD_ALPHA 'a'
#define CMD_MIXED 'm'
#define CMD_SECURE 's'
#define CMD_UNAMBIGUOUS 'u'

// Password generation function prototypes
char *generate_numeric(int length);
char *generate_alpha(int length);
char *generate_mixed(int length);
char *generate_secure(int length);
char *generate_unambiguous(int length);

#endif

