#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h> // For close()
#include "protocol.h"

// Optional: Add an explicit declaration for 'close'
extern int close(int fd);

// Prints the help menu
void print_help_menu() {
    printf("Password Generator Help Menu\n");
    printf("Commands:\n");
    printf("  h        : show this help menu\n");
    printf("  n LENGTH : generate numeric password (digits only)\n");
    printf("  a LENGTH : generate alphabetic password (lowercase letters)\n");
    printf("  m LENGTH : generate mixed password (lowercase letters and numbers)\n");
    printf("  s LENGTH : generate secure password (uppercase, lowercase, numbers, symbols)\n");
    printf("  u LENGTH : generate unambiguous secure password (no similar-looking characters)\n");
    printf("  q        : quit application\n");
    printf("  LENGTH must be between 6 and 32 characters\n");
}

int main() {
    int client_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (client_socket < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in server_addr = {0};
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    if (inet_pton(AF_INET, SERVER_ADDRESS, &server_addr.sin_addr) <= 0) {
        perror("Invalid server address");
        exit(EXIT_FAILURE);
    }

    char buffer[BUFFER_SIZE];
    while (1) {
        printf("Enter command: ");
        fgets(buffer, BUFFER_SIZE, stdin);
        buffer[strcspn(buffer, "\n")] = '\0';

        if (buffer[0] == CMD_QUIT) {
            printf("Exiting client...\n");
            break;
        }

        if (buffer[0] == CMD_HELP) {
            print_help_menu();
            continue;
        }

        if (sendto(client_socket, buffer, strlen(buffer), 0,
                   (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
            perror("Send failed");
            continue;
        }

        struct sockaddr_in response_addr;
        socklen_t response_addr_len = sizeof(response_addr);
        int bytes_received = recvfrom(client_socket, buffer, BUFFER_SIZE, 0,
                                      (struct sockaddr *)&response_addr, &response_addr_len);
        if (bytes_received < 0) {
            perror("Receive failed");
            continue;
        }

        buffer[bytes_received] = '\0';
        printf("Generated Password: %s\n", buffer);
    }

    close(client_socket);  // Close the socket after shutdown

    return 0;
}

